# AI広告ディレクター — GitHub → Netlify デプロイ手順

## 構成
```
.
├── index.html                     ← ツール本体
├── netlify.toml                   ← Netlifyのビルド設定
├── .gitignore
└── netlify/
    └── functions/
        └── claude.js               ← Anthropic APIへのプロキシ（APIキーはここでのみ使用）
```

`index.html` は Anthropic API を直接呼ばず、`/.netlify/functions/claude` という
自サイト内のエンドポイントを呼びます。そのエンドポイント（`claude.js`）が
サーバー側でAPIキーを付与してAnthropic APIに転送します。
**APIキーはGitHubにpushするコードには一切含まれません**（Netlifyの環境変数に別途設定します）。

---

## STEP 1：このフォルダをGitHubリポジトリにする

ローカルPCにこのフォルダを展開し、ターミナルで移動してから：

```bash
git init
git add .
git commit -m "Initial commit: AI広告ディレクター"
```

GitHubで新規リポジトリを作成（Public / Privateどちらでも可。README等は追加しない状態で作成）したら、
表示される案内に従ってpush：

```bash
git remote add origin https://github.com/【あなたのアカウント名】/【リポジトリ名】.git
git branch -M main
git push -u origin main
```

---

## STEP 2：NetlifyでGitHubリポジトリを連携する

1. https://app.netlify.com にログイン
2. 「Add new site」→「Import an existing project」
3. 「Deploy with GitHub」を選び、認証してSTEP1で作ったリポジトリを選択
4. ビルド設定はそのままでOK（`netlify.toml` の内容が自動で読み込まれます）
   - Build command：空欄のまま
   - Publish directory：`.`（そのまま）
5. 「Deploy site」をクリック

この時点でサイトは公開されますが、まだAPIキーが未設定なのでAI生成は動きません。

---

## STEP 3：APIキーを環境変数に設定する

1. Anthropic Console（https://console.anthropic.com）にログインし、
   Settings → API Keys → Create Key でAPIキーを発行（`sk-ant-...`）
2. Netlifyのサイト管理画面 →「Site configuration」→「Environment variables」→「Add a variable」
   - Key：`ANTHROPIC_API_KEY`
   - Value：発行したAPIキー
3. 保存後、「Deploys」タブから「Trigger deploy」→「Deploy site」で**再デプロイ**
   （環境変数は再デプロイしないと反映されません）

---

## STEP 4：動作確認

再デプロイ完了後、発行されたURL（`https://xxxxx.netlify.app`）にアクセスし、
案件シートを入力して「ディレクション開始」→ 各STEPの生成が動けば成功です。

---

## 更新したいとき

コードを直したら、以下だけでOKです（Netlifyが自動で再ビルド・再デプロイします）：

```bash
git add .
git commit -m "更新内容のメモ"
git push
```

---

## 費用について
STEPを1つ生成するたびにAnthropic APIを呼び出すため、利用量に応じて
Anthropic Console側で従量課金が発生します（Netlify自体は無料枠で足りることが多いです）。
Anthropic Consoleの「Settings → Limits」で使用上限を設定しておくと安心です。

## うまく動かないときは
- ブラウザの開発者ツール（コンソール）にエラーが出ていないか確認
- Netlify管理画面 →「Functions」タブでログを確認（`claude` 関数が呼ばれているか、エラーが出ていないか）
- 「ANTHROPIC_API_KEY is not set」と出る場合は環境変数の設定漏れ、または設定後の再デプロイ忘れです
- GitHubにpushしたのにNetlifyに反映されない場合は、Netlify管理画面の「Deploys」でビルドが走っているか確認してください
